#ifndef CUSTOMIZED_ROUTINES_H
#define CUSTOMIZED_ROUTINES_H

float detectionThreshold = 1008; // recognition of obstacle at this sensor value (max value 1024)
float sensorLow[2]={39,42}; // array storing lowest sensor value
float sensorHigh[2]={770,770}; // array storing highest sensor value
float speedCorrection = -0.05;

void setMotors(int mLeft, int mRight){
  if(mLeft<=0){
    digitalWrite(7, HIGH);
  }
  else {
    digitalWrite(7, LOW);
  }
  analogWrite(9,abs(mLeft));

  if(mRight>=0){
    digitalWrite(11, LOW);
  }
  else {
    digitalWrite(11, HIGH);
  }
  analogWrite(10,abs(mRight));
}

// set magnet state to be engaged (1) or disengaged (0)
void setServo(Servo myservo, bool state) {
  if(state){
	myservo.write(0);
  }
  else{
	myservo.write(180);
  }
  delay(100);
}

#endif
